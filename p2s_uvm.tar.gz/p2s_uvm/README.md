
/*******************************************************************************
Copyright (c) 2004-2018, AMIQ Consulting srl. All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
******************************************************************************/

* Project name: Parallel-to-Serial practical application

* Project contents:
  - doc    : contains required documents to complete the exercise
  - doc/cs : contains cheat sheets for Verilog/SystemVerilog and the SystemVerilog standard
  - rtl    : contains the RTL/Verilog sources
  - sim    : the simulation folder where the simulations should be run
  - tb     : verification environment sources

* How to start?
  You start by reading the doc/Parallel_to_Serial_Application.pdf

Enjoy!











